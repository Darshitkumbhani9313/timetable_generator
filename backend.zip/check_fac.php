<?php
$conn = new mysqli('localhost', 'root', '', 'timetable_db');
if ($conn->connect_error) die('Connection failed: ' . $conn->connect_error);
$res = $conn->query('SELECT email, password FROM teachers LIMIT 5');
if($res && $res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        echo "Email: {$row['email']}, PasswordHash: {$row['password']}\n";
    }
} else {
    echo "No teachers found in the database.\n";
}
$conn->close();
?>

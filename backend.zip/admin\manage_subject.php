<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add_subject'])){
        $department_id = $_POST['department_id'];
        $semester = $_POST['semester'];
        $subject_code = trim($_POST['subject_code']);
        $subject_name = trim($_POST['subject_name']);
        $hours_per_week = $_POST['hours_per_week'];
        
        if(!empty($subject_code) && !empty($subject_name)){
            try {
                $stmt = $pdo->prepare("INSERT INTO subjects (department_id, semester, subject_code, subject_name, hours_per_week) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$department_id, $semester, $subject_code, $subject_name, $hours_per_week]);
                $message = "<div class='alert alert-success'>Subject added successfully.</div>";
            } catch(PDOException $e) {
                $message = "<div class='alert alert-danger'>Error: Subject code may already exist.</div>";
            }
        }
    } elseif(isset($_POST['delete_subject'])){
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM subjects WHERE id = ?")->execute([$id]);
        $message = "<div class='alert alert-success'>Subject deleted successfully.</div>";
    }
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
$subjects = $pdo->query("SELECT s.*, d.name as dept_name FROM subjects s LEFT JOIN departments d ON s.department_id = d.id ORDER BY d.name, s.semester, s.subject_name")->fetchAll();

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Manage Subjects</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Add Subject</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Department</label>
                    <select name="department_id" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Semester</label>
                    <select name="semester" class="form-select" required>
                        <option value="">-- Select Semester --</option>
                        <?php for($i=1; $i<=10; $i++): ?>
                            <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Subject Code</label>
                    <input type="text" name="subject_code" class="form-control" placeholder="e.g. CS101" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Subject Name</label>
                    <input type="text" name="subject_name" class="form-control" placeholder="e.g. Data Structures" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Hours Per Week</label>
                    <input type="number" name="hours_per_week" class="form-control" min="1" max="10" value="4" required>
                </div>
                <button type="submit" name="add_subject" class="btn btn-primary w-100">Add Subject</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Existing Subjects</h5>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Dept & Sem</th>
                            <th>Hrs/Wk</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($subjects as $sub): ?>
                        <tr>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($sub['subject_code']); ?></span></td>
                            <td class="fw-bold"><?php echo htmlspecialchars($sub['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($sub['dept_name']); ?> - Sem <?php echo $sub['semester']; ?></td>
                            <td><?php echo $sub['hours_per_week']; ?></td>
                            <td>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this subject?');">
                                    <input type="hidden" name="id" value="<?php echo $sub['id']; ?>">
                                    <button type="submit" name="delete_subject" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($subjects)): ?>
                            <tr><td colspan="5" class="text-center text-muted">No subjects found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

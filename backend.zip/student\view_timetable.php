<?php
session_start();
if(!isset($_SESSION['student_id'])) { header("Location: student_login.php"); exit; }
require_once '../config/db.php';

$s_id = $_SESSION['student_id'];

// Get student info
$stmt = $pdo->prepare("SELECT s.*, d.name as dept_name FROM students s LEFT JOIN departments d ON s.department_id = d.id WHERE s.id = ?");
$stmt->execute([$s_id]);
$student = $stmt->fetch();

$dept_id = $student['department_id'];
$sem = $student['semester'];

$timetable = [];

// Fetch class timetable
$stmt = $pdo->prepare("SELECT t.*, d.day_of_week, d.start_time, d.end_time, s.subject_name, s.subject_code, c.room_number, tc.name as teacher_name 
                       FROM timetable t
                       JOIN time_slots d ON t.time_slot_id = d.id
                       JOIN subjects s ON t.subject_id = s.id
                       JOIN classrooms c ON t.classroom_id = c.id
                       JOIN teachers tc ON t.teacher_id = tc.id
                       WHERE t.department_id = ? AND t.semester = ?
                       ORDER BY d.start_time");
$stmt->execute([$dept_id, $sem]);
$entries = $stmt->fetchAll();

foreach($entries as $val) {
    $timetable[$val['day_of_week']][$val['start_time'].'-'.$val['end_time']] = $val;
}

// Get unique days and times for matrix headers
$days = [];
$times = [];
$timeQ = $pdo->query("SELECT * FROM time_slots ORDER BY start_time")->fetchAll();
foreach($timeQ as $t) {
    if(!in_array($t['day_of_week'], $days)) $days[] = $t['day_of_week'];
    $times[$t['start_time'].'-'.$t['end_time']] = $t['is_break'] ?? 0;
}
$days = array_unique($days);

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Class Schedule</h2>
        <div>
            <button onclick="window.print()" class="btn btn-outline-primary shadow-sm me-2"><i class="bi bi-printer me-2"></i>Print/Download PDF</button>
            <a href="student_dashboard.php" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Dashboard</a>
        </div>
    </div>
</div>

<div class="card p-4 shadow-sm border-0 print-section">
    <div class="text-center mb-4 pb-3 border-bottom">
        <h4 class="fw-bold text-primary mb-1"><i class="bi bi-calendar-grid-3x3 me-2"></i>Weekly Timetable</h4>
        <h5 class="text-muted"><?php echo htmlspecialchars($student['dept_name']); ?> - Semester <?php echo htmlspecialchars($student['semester']); ?></h5>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered text-center align-middle bg-white">
            <thead class="table-dark">
                <tr>
                    <th>Day / Time</th>
                    <?php foreach($times as $time => $is_break): ?>
                        <th <?php echo $is_break ? 'class="bg-warning text-dark bg-opacity-50"' : ''; ?>><?php 
                            $tparts = explode('-', $time);
                            echo date("g:i A", strtotime($tparts[0])) . "<br> - <br>" . date("g:i A", strtotime($tparts[1])); 
                            if($is_break) echo '<br><small class="fw-bold">BREAK</small>';
                        ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($days as $day): ?>
                    <tr>
                        <td class="fw-bold bg-light" style="width: 10%"><?php echo htmlspecialchars($day); ?></td>
                        <?php foreach($times as $time => $is_break): ?>
                            <td <?php echo $is_break ? 'class="bg-warning bg-opacity-10"' : ''; ?>>
                                <?php if($is_break): ?>
                                    <div class="d-flex align-items-center justify-content-center h-100"><span class="badge bg-warning text-dark"><i class="bi bi-cup-hot me-1"></i>BREAK</span></div>
                                <?php elseif(isset($timetable[$day][$time])): 
                                    $entry = $timetable[$day][$time];
                                ?>
                                    <div class="p-2 border border-info border-opacity-25 rounded bg-info bg-opacity-10 h-100">
                                        <div class="fw-bold text-primary mb-1">
                                            <?php echo htmlspecialchars($entry['subject_name']); ?>
                                        </div>
                                        <small class="text-muted d-block mb-1"><?php echo htmlspecialchars($entry['subject_code']); ?></small>
                                        <small class="text-dark fw-bold d-block"><i class="bi bi-person me-1"></i><?php echo htmlspecialchars($entry['teacher_name']); ?></small>
                                        <span class="badge bg-dark mt-1"><i class="bi bi-door-open me-1"></i>Room <?php echo htmlspecialchars($entry['room_number']); ?></span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted small">Free</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
@media print {
    body * {
        visibility: hidden;
    }
    .print-section, .print-section * {
        visibility: visible;
    }
    .print-section {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }
}
</style>
<?php require_once '../includes/footer.php'; ?>

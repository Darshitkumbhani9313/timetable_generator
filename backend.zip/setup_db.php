<?php
$host = 'localhost';
$username = 'root'; // Adjust if needed
$password = ''; // Adjust if needed

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create DB
    $sql = "CREATE DATABASE IF NOT EXISTS timetable_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    $pdo->exec($sql);
    echo "Database created successfully<br>";
    
    $pdo->exec("USE timetable_db");

    // Create Tables
    $tables = [
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS departments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE
        )",
        "CREATE TABLE IF NOT EXISTS subjects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            department_id INT,
            semester INT NOT NULL,
            subject_code VARCHAR(20) NOT NULL UNIQUE,
            subject_name VARCHAR(100) NOT NULL,
            hours_per_week INT NOT NULL,
            FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
        )",
        "CREATE TABLE IF NOT EXISTS teachers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            department_id INT,
            FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
        )",
        "CREATE TABLE IF NOT EXISTS teacher_subjects (
            teacher_id INT,
            subject_id INT,
            PRIMARY KEY (teacher_id, subject_id),
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",
        "CREATE TABLE IF NOT EXISTS classrooms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_number VARCHAR(20) NOT NULL UNIQUE,
            capacity INT NOT NULL,
            type ENUM('Classroom', 'Computer Lab') DEFAULT 'Classroom'
        )",
        "CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            enrollment_number VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            department_id INT,
            semester INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
        )",
        "CREATE TABLE IF NOT EXISTS time_slots (
            id INT AUTO_INCREMENT PRIMARY KEY,
            day_of_week VARCHAR(10) NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            is_break TINYINT(1) DEFAULT 0
        )",
        "CREATE TABLE IF NOT EXISTS timetable (
            id INT AUTO_INCREMENT PRIMARY KEY,
            department_id INT,
            semester INT,
            subject_id INT,
            teacher_id INT,
            classroom_id INT,
            time_slot_id INT,
            FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
            FOREIGN KEY (classroom_id) REFERENCES classrooms(id) ON DELETE CASCADE,
            FOREIGN KEY (time_slot_id) REFERENCES time_slots(id) ON DELETE CASCADE
        )"
    ];

    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
    echo "Tables created successfully<br>";

    // Insert Default Admin (password: admin123)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admins");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO admins (username, password) VALUES ('admin', '$hash')");
        echo "Default admin created (username: admin, password: admin123)<br>";
    }

    // Insert Default Time Slots
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM time_slots");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        $slots = [
            ['07:30:00', '08:25:00', 0],
            ['08:25:00', '09:20:00', 0],
            ['09:20:00', '09:50:00', 1],
            ['09:50:00', '10:45:00', 0],
            ['10:45:00', '11:40:00', 0],
            ['11:40:00', '11:50:00', 1],
            ['11:50:00', '12:45:00', 0],
            ['12:45:00', '13:40:00', 0]
        ];
        $insertSlot = $pdo->prepare("INSERT INTO time_slots (day_of_week, start_time, end_time, is_break) VALUES (?, ?, ?, ?)");
        foreach ($days as $day) {
            foreach ($slots as $slot) {
                $insertSlot->execute([$day, $slot[0], $slot[1], $slot[2]]);
            }
        }
        echo "Default time slots created<br>";
    }

    echo "<h3>Setup Complete!</h3>";
    echo "<a href='index.php'>Go to Homepage</a>";

} catch(PDOException $e) {
    die("ERROR: " . $e->getMessage());
}
?>

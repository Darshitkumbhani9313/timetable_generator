<?php
session_start();
require_once '../config/db.php';

if(isset($_SESSION['teacher_id'])) {
    header("Location: teacher_dashboard.php");
    exit;
}

$error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password FROM teachers WHERE email = ?");
    $stmt->execute([$email]);
    $teacher = $stmt->fetch();

    if($teacher && password_verify($password, $teacher['password'])) {
        $_SESSION['teacher_id'] = $teacher['id'];
        header("Location: teacher_dashboard.php");
        exit;
    } else {
        $error = 'Invalid email or password';
    }
}
require_once '../includes/header.php';
?>
<div class="login-container">
    <div class="card p-4">
        <div class="text-center mb-4">
            <i class="bi bi-person-workspace" style="font-size: 3rem; color: var(--primary-color);"></i>
            <h3 class="mt-2 fw-bold text-dark">Faculty Login</h3>
            <p class="text-muted">Login using your registered email.</p>
        </div>
        <?php if($error): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-bold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-bold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fs-5">Login</button>
        </form>
        <div class="mt-4 text-center">
            <a href="../index.php" class="text-decoration-none text-muted"><i class="bi bi-arrow-left me-1"></i> Back to Home</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/config/db.php';

try {
    $pdo->beginTransaction();

    // 1. Delete old time slots (this will delete linked timetable entries due to CASCADE)
    $pdo->exec("DELETE FROM time_slots");

    // 2. Define the new slots
    $slots = [
        ['07:30:00', '08:25:00'],
        ['08:25:00', '09:20:00'],
        // Break 09:20 - 09:50
        ['09:50:00', '10:45:00'],
        ['10:45:00', '11:40:00'],
        // Break 11:40 - 11:50
        ['11:50:00', '12:45:00'],
        ['12:45:00', '13:40:00']
    ];
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    $insert = $pdo->prepare("INSERT INTO time_slots (day_of_week, start_time, end_time) VALUES (?, ?, ?)");
    
    $count = 0;
    foreach ($days as $day) {
        foreach ($slots as $slot) {
            $insert->execute([$day, $slot[0], $slot[1]]);
            $count++;
        }
    }

    $pdo->commit();
    echo "Successfully updated time slots to match the new schedule.\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "Error: " . $e->getMessage() . "\n";
}
?>

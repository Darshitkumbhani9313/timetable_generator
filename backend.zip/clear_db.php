<?php
$host = 'localhost';
$username = 'root'; // Adjust if needed
$password = ''; // Adjust if needed

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Drop the database to clear all data
    $pdo->exec("DROP DATABASE IF EXISTS timetable_db");
    echo "Database timetable_db has been dropped successfully.\n";

} catch(PDOException $e) {
    die("ERROR: " . $e->getMessage() . "\n");
}
?>

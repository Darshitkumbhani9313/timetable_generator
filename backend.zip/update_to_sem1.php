<?php
require_once __DIR__ . '/config/db.php';

try {
    $pdo->exec("UPDATE subjects SET semester = 1 WHERE department_id = (SELECT id FROM departments WHERE name='BCA')");
    echo "Successfully moved all BCA subjects to Semester 1.\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

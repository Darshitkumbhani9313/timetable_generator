<?php
session_start();
require_once '../config/db.php';

if(isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = 'Invalid username or password';
    }
}
require_once '../includes/header.php';
?>
<div class="login-container">
    <div class="card p-4">
        <div class="text-center mb-4">
            <i class="bi bi-shield-lock-fill" style="font-size: 3rem; color: var(--primary-color);"></i>
            <h3 class="mt-2 fw-bold text-dark">Admin Login</h3>
            <p class="text-muted">Login to manage the timetable system.</p>
        </div>
        <?php if($error): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-bold">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Enter username" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-bold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fs-5">Login</button>
        </form>
        <div class="mt-4 text-center">
            <a href="../index.php" class="text-decoration-none text-muted"><i class="bi bi-arrow-left me-1"></i> Back to Home</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/config/db.php';

try {
    $pdo->beginTransaction();
    $pdo->exec("DELETE FROM timetable");

    $time_slots = $pdo->query("SELECT * FROM time_slots ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time")->fetchAll(PDO::FETCH_ASSOC);
    $classrooms = $pdo->query("SELECT * FROM classrooms ORDER BY capacity DESC")->fetchAll(PDO::FETCH_ASSOC);
    $theory_rooms = array_filter($classrooms, fn($r) => $r['type'] !== 'Computer Lab');
    $lab_rooms = array_filter($classrooms, fn($r) => $r['type'] === 'Computer Lab');

    $subjects = $pdo->query("SELECT * FROM subjects")->fetchAll(PDO::FETCH_ASSOC);
    $teacher_subjects = $pdo->query("SELECT teacher_id, subject_id FROM teacher_subjects")->fetchAll(PDO::FETCH_ASSOC);
    $sub_teacher_map = [];
    foreach($teacher_subjects as $ts) {
        $sub_teacher_map[$ts['subject_id']][] = $ts['teacher_id'];
    }

    $success_count = 0;
    $fail_count = 0;

    foreach($subjects as $sub) {
        $dept_id = $sub['department_id'];
        $sem = $sub['semester'];
        $sub_id = $sub['id'];
        
        $teachers_for_sub = $sub_teacher_map[$sub_id] ?? [];
        if(empty($teachers_for_sub)) {
            $fail_count++;
            continue;
        }
        $t_id = $teachers_for_sub[0];
        
        $theory_scheduled = 0;
        $lab_scheduled = 0; 
        
        for($i = 0; $i < count($time_slots) - 1; $i++) {
            if($lab_scheduled >= 1) break;
            $slot1 = $time_slots[$i];
            $slot2 = $time_slots[$i+1];
            if($slot1['day_of_week'] != $slot2['day_of_week']) continue;
            if($slot1['is_break'] == 1 || $slot2['is_break'] == 1) continue;
            
            $s1_id = $slot1['id'];
            $s2_id = $slot2['id'];
            
            $t_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ? AND time_slot_id IN (?, ?)");
            $t_busy->execute([$t_id, $s1_id, $s2_id]);
            if($t_busy->fetchColumn() > 0) continue; 
            
            $c_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE department_id = ? AND semester = ? AND time_slot_id IN (?, ?)");
            $c_busy->execute([$dept_id, $sem, $s1_id, $s2_id]);
            if($c_busy->fetchColumn() > 0) continue; 
            
            $assigned_lab = null;
            foreach($lab_rooms as $room) {
                $r_id = $room['id'];
                $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id IN (?, ?)");
                $r_busy->execute([$r_id, $s1_id, $s2_id]);
                if($r_busy->fetchColumn() == 0) {
                    $assigned_lab = $r_id;
                    break;
                }
            }
            
            if($assigned_lab) {
                $stmt = $pdo->prepare("INSERT INTO timetable (department_id, semester, subject_id, teacher_id, classroom_id, time_slot_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_lab, $s1_id]);
                $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_lab, $s2_id]);
                $lab_scheduled++;
            }
        }

        foreach($time_slots as $slot) {
            if($theory_scheduled >= 3) break; 
            if($slot['is_break'] == 1) continue;
            $slot_id = $slot['id'];
            
            $c_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE department_id = ? AND semester = ? AND time_slot_id = ?");
            $c_busy->execute([$dept_id, $sem, $slot_id]);
            if($c_busy->fetchColumn() > 0) continue; 
            
            $t_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ? AND time_slot_id = ?");
            $t_busy->execute([$t_id, $slot_id]);
            if($t_busy->fetchColumn() > 0) continue; 
            
            $assigned_room = null;
            foreach($theory_rooms as $room) {
                $r_id = $room['id'];
                $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id = ?");
                $r_busy->execute([$r_id, $slot_id]);
                if($r_busy->fetchColumn() == 0) {
                    $assigned_room = $r_id;
                    break;
                }
            }
            if($assigned_room) {
                $stmt = $pdo->prepare("INSERT INTO timetable (department_id, semester, subject_id, teacher_id, classroom_id, time_slot_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_room, $slot_id]);
                $theory_scheduled++;
            }
        }
        
        if($lab_scheduled == 1 && $theory_scheduled == 3) {
            $success_count++;
        } else {
            $fail_count++;
            echo "Subject {$sub['subject_code']} failed to completely schedule. ($lab_scheduled lab, $theory_scheduled theory)\n";
        }
    }
    
    $pdo->commit();
    echo "Success: $success_count, Fails: $fail_count\n";

    $count = $pdo->query("SELECT COUNT(*) FROM timetable")->fetchColumn();
    echo "Total scheduled rows: $count\n";

    $verify = $pdo->query("
        SELECT t.semester, s.subject_name, c.type, count(*) as slot_count 
        FROM timetable t 
        JOIN subjects s ON t.subject_id = s.id 
        JOIN classrooms c ON t.classroom_id = c.id
        GROUP BY t.semester, t.subject_id, c.type
        ORDER BY t.semester ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    foreach($verify as $v) {
        echo "Sem {$v['semester']} | {$v['subject_name']} | {$v['type']} => {$v['slot_count']} slots\n";
    }

} catch(Exception $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    echo "Error: " . $e->getMessage() . "\n";
}
?>

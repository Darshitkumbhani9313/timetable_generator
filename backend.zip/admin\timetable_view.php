<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();

$selected_dept = $_GET['department_id'] ?? '';
$selected_sem = $_GET['semester'] ?? '';

$timetable = [];
if($selected_dept && $selected_sem) {
    // Fetch slots and map details
    $slots = $pdo->query("SELECT * FROM time_slots ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time")->fetchAll();
    
    $stmt = $pdo->prepare("SELECT t.*, d.day_of_week, d.start_time, d.end_time, s.subject_name, s.subject_code, tc.name as teacher_name, c.room_number 
                           FROM timetable t
                           JOIN time_slots d ON t.time_slot_id = d.id
                           JOIN subjects s ON t.subject_id = s.id
                           JOIN teachers tc ON t.teacher_id = tc.id
                           JOIN classrooms c ON t.classroom_id = c.id
                           WHERE t.department_id = ? AND t.semester = ?");
    $stmt->execute([$selected_dept, $selected_sem]);
    $entries = $stmt->fetchAll();
    
    // Group by Day and Time
    foreach($entries as $val) {
        $timetable[$val['day_of_week']][$val['start_time'].'-'.$val['end_time']] = $val;
    }
}

// Get unique days and times for matrix headers
$days = [];
$times = [];
$timeQ = $pdo->query("SELECT * FROM time_slots ORDER BY start_time")->fetchAll();
foreach($timeQ as $t) {
    if(!in_array($t['day_of_week'], $days)) $days[] = $t['day_of_week'];
    $times[$t['start_time'].'-'.$t['end_time']] = $t['is_break'] ?? 0;
}
$days = array_unique($days);

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>View Timetables</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back</a>
    </div>
</div>

<div class="card p-4 mb-4">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-4">
            <label class="form-label">Select Department</label>
            <select name="department_id" class="form-select" required>
                <option value="">-- Choose --</option>
                <?php foreach($departments as $d): ?>
                    <option value="<?php echo $d['id']; ?>" <?php echo ($selected_dept == $d['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Select Semester</label>
            <select name="semester" class="form-select" required>
                <option value="">-- Choose --</option>
                <?php for($i=1; $i<=10; $i++): ?>
                    <option value="<?php echo $i; ?>" <?php echo ($selected_sem == $i) ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-2"></i>View Timetable</button>
        </div>
    </form>
</div>

<?php if($selected_dept && $selected_sem): ?>
    <div class="card p-4 shadow-sm border-0">
        <h4 class="fw-bold mb-4 text-center">Timetable - Semester <?php echo htmlspecialchars($selected_sem); ?></h4>
        <div class="table-responsive">
            <table class="table table-bordered text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Day / Time</th>
                        <?php foreach($times as $time => $is_break): ?>
                            <th <?php echo $is_break ? 'class="bg-warning text-dark bg-opacity-50"' : ''; ?>><?php 
                                $tparts = explode('-', $time);
                                echo date("g:i A", strtotime($tparts[0])) . "<br> - <br>" . date("g:i A", strtotime($tparts[1])); 
                                if($is_break) echo '<br><small class="fw-bold">BREAK</small>';
                            ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($days as $day): ?>
                        <tr>
                            <td class="fw-bold bg-light"><?php echo htmlspecialchars($day); ?></td>
                            <?php foreach($times as $time => $is_break): ?>
                                <td <?php echo $is_break ? 'class="bg-warning bg-opacity-10"' : ''; ?>>
                                    <?php if($is_break): ?>
                                        <div class="d-flex align-items-center justify-content-center h-100"><span class="badge bg-warning text-dark"><i class="bi bi-cup-hot me-1"></i>BREAK</span></div>
                                    <?php elseif(isset($timetable[$day][$time])): 
                                        $entry = $timetable[$day][$time];
                                    ?>
                                        <div class="badge bg-primary text-wrap mb-1" style="width: 100%;">
                                            <?php echo htmlspecialchars($entry['subject_name']); ?> (<?php echo htmlspecialchars($entry['subject_code']); ?>)
                                        </div><br>
                                        <small class="text-muted fw-bold d-block"><i class="bi bi-person me-1"></i><?php echo htmlspecialchars($entry['teacher_name']); ?></small>
                                        <small class="text-success fw-bold d-block"><i class="bi bi-door-open me-1"></i>Room: <?php echo htmlspecialchars($entry['room_number']); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted small">---</span>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>

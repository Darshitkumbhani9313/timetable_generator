<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add_classroom'])){
        $room_number = trim($_POST['room_number']);
        $capacity = (int)$_POST['capacity'];
        $type = $_POST['type'];
        
        if(!empty($room_number) && $capacity > 0){
            try {
                $stmt = $pdo->prepare("INSERT INTO classrooms (room_number, capacity, type) VALUES (?, ?, ?)");
                $stmt->execute([$room_number, $capacity, $type]);
                $message = "<div class='alert alert-success'>Classroom added successfully.</div>";
            } catch(PDOException $e) {
                $message = "<div class='alert alert-danger'>Error: Room number may already exist.</div>";
            }
        }
    } elseif(isset($_POST['delete_classroom'])){
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM classrooms WHERE id = ?")->execute([$id]);
        $message = "<div class='alert alert-success'>Classroom deleted successfully.</div>";
    }
}

$classrooms = $pdo->query("SELECT * FROM classrooms ORDER BY room_number")->fetchAll();

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Manage Classrooms</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Add Room / Lab</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Room Number</label>
                    <input type="text" name="room_number" class="form-control" placeholder="e.g. 101, Lab-A" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Capacity (Students)</label>
                    <input type="number" name="capacity" class="form-control" min="10" max="300" value="60" required>
                </div>
                <div class="mb-4">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" required>
                        <option value="Classroom">Classroom</option>
                        <option value="Computer Lab">Computer Lab</option>
                    </select>
                </div>
                <button type="submit" name="add_classroom" class="btn btn-primary w-100">Add Room</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Existing Rooms</h5>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Room No.</th>
                            <th>Capacity</th>
                            <th>Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($classrooms as $room): ?>
                        <tr>
                            <td class="fw-bold"><?php echo htmlspecialchars($room['room_number']); ?></td>
                            <td><?php echo $room['capacity']; ?> seats</td>
                            <td>
                                <?php if($room['type'] == 'Computer Lab'): ?>
                                    <span class="badge bg-info text-dark"><i class="bi bi-pc-display me-1"></i>Computer Lab</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><i class="bi bi-easel me-1"></i>Classroom</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this classroom?');">
                                    <input type="hidden" name="id" value="<?php echo $room['id']; ?>">
                                    <button type="submit" name="delete_classroom" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($classrooms)): ?>
                            <tr><td colspan="4" class="text-center text-muted">No classrooms found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

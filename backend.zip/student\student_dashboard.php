<?php
session_start();
if(!isset($_SESSION['student_id'])) { header("Location: student_login.php"); exit; }
require_once '../config/db.php';

$s_id = $_SESSION['student_id'];

// Get student info
$stmt = $pdo->prepare("SELECT s.*, d.name as dept_name FROM students s LEFT JOIN departments d ON s.department_id = d.id WHERE s.id = ?");
$stmt->execute([$s_id]);
$student = $stmt->fetch();

$dept_id = $student['department_id'];
$sem = $student['semester'];

// Get today's classes
$today = date('l');
$stmt = $pdo->prepare("SELECT t.*, s.subject_name, s.subject_code, c.room_number, ts.start_time, ts.end_time, tc.name as teacher_name
                       FROM timetable t
                       JOIN subjects s ON t.subject_id = s.id
                       JOIN classrooms c ON t.classroom_id = c.id
                       JOIN time_slots ts ON t.time_slot_id = ts.id
                       JOIN teachers tc ON t.teacher_id = tc.id
                       WHERE t.department_id = ? AND t.semester = ? AND ts.day_of_week = ?
                       ORDER BY ts.start_time");
$stmt->execute([$dept_id, $sem, $today]);
$todays_classes = $stmt->fetchAll();

// Get total subjects in semester
$stmt = $pdo->prepare("SELECT COUNT(*) FROM subjects WHERE department_id = ? AND semester = ?");
$stmt->execute([$dept_id, $sem]);
$subject_count = $stmt->fetchColumn();

require_once '../includes/header.php';
?>
<div class="row align-items-center mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-dark">Hello, <?php echo htmlspecialchars($student['name']); ?></h2>
        <p class="text-muted mb-0"><i class="bi bi-mortarboard me-1"></i> <?php echo htmlspecialchars($student['dept_name']); ?> - Semester <?php echo htmlspecialchars($student['semester']); ?></p>
        <p class="text-muted small"><i class="bi bi-person-badge me-1"></i> <?php echo htmlspecialchars($student['enrollment_number']); ?></p>
    </div>
    <div class="col-md-4 text-md-end">
        <a href="view_timetable.php" class="btn btn-primary btn-lg shadow-sm"><i class="bi bi-calendar-grid-3x3 me-2"></i>My Class Timetable</a>
    </div>
</div>

<div class="row g-4 mb-5">
    <div class="col-md-6">
        <div class="card bg-info text-white p-4 border-0 h-100" style="background: linear-gradient(135deg, #0ea5e9, #38bdf8) !important;">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 text-white-50">Semester Subjects</h5>
                    <h2 class="fw-bold mb-0 mt-2"><?php echo $subject_count; ?></h2>
                </div>
                <i class="bi bi-journal-check border rounded-circle p-3 fs-3 bg-white bg-opacity-25"></i>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-success text-white p-4 border-0 h-100" style="background: linear-gradient(135deg, #10b981, #34d399) !important;">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 text-white-50">Classes Today (<?php echo $today; ?>)</h5>
                    <h2 class="fw-bold mb-0 mt-2"><?php echo count($todays_classes); ?></h2>
                </div>
                <i class="bi bi-clock-history border rounded-circle p-3 fs-3 bg-white bg-opacity-25"></i>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 align-items-stretch">
    <div class="col-lg-8">
        <div class="card p-4 shadow-sm border-0 h-100">
            <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="bi bi-calendar-day me-2 text-primary"></i>Today's Class Schedule</h5>
            <?php if(!empty($todays_classes)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Time</th>
                                <th>Subject</th>
                                <th>Faculty</th>
                                <th>Room</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($todays_classes as $class): ?>
                                <tr>
                                    <td class="fw-bold text-nowrap">
                                        <?php echo date("g:i A", strtotime($class['start_time'])); ?> <br>
                                        <small class="text-muted fw-normal">to <?php echo date("g:i A", strtotime($class['end_time'])); ?></small>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-primary"><?php echo htmlspecialchars($class['subject_name']); ?></div>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($class['subject_code']); ?></span>
                                    </td>
                                    <td><i class="bi bi-person text-muted me-1"></i><?php echo htmlspecialchars($class['teacher_name']); ?></td>
                                    <td><span class="badge bg-dark"><i class="bi bi-door-open me-1"></i><?php echo htmlspecialchars($class['room_number']); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="p-4 bg-light rounded-circle d-inline-block mb-3">
                        <i class="bi bi-emoji-smile text-success fs-1"></i>
                    </div>
                    <h5 class="fw-bold">No classes scheduled for today!</h5>
                    <p class="text-muted mb-0">Use this time for self-study or assignments.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card p-4 shadow-sm border-0 text-center text-white h-100 d-flex justify-content-center align-items-center" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));">
            <i class="bi bi-printer display-1 mb-3"></i>
            <h4 class="fw-bold">Download Timetable</h4>
            <p class="text-white-50">Get a printable version of your full weekly schedule.</p>
            <a href="view_timetable.php" class="btn btn-light btn-lg fw-bold mt-2 text-primary">View & Print PDF</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

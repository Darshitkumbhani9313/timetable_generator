<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add_teacher'])){
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $department_id = $_POST['department_id'];
        $subject_ids = $_POST['subject_ids'] ?? []; // Array of assigned subjects
        
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO teachers (name, email, password, department_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $password, $department_id]);
            $teacher_id = $pdo->lastInsertId();
            
            // Assign subjects
            if(!empty($subject_ids)){
                $stmtSub = $pdo->prepare("INSERT INTO teacher_subjects (teacher_id, subject_id) VALUES (?, ?)");
                foreach($subject_ids as $sid){
                    $stmtSub->execute([$teacher_id, $sid]);
                }
            }
            $pdo->commit();
            $message = "<div class='alert alert-success'>Faculty added successfully.</div>";
        } catch(PDOException $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Error: Email may already exist.</div>";
        }
    } elseif(isset($_POST['delete_teacher'])){
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM teachers WHERE id = ?")->execute([$id]);
        $message = "<div class='alert alert-success'>Faculty deleted successfully.</div>";
    }
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY subject_name")->fetchAll();

$teachersQ = $pdo->query("SELECT t.*, d.name as dept_name FROM teachers t LEFT JOIN departments d ON t.department_id = d.id ORDER BY t.name")->fetchAll();

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Manage Faculty</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Add Faculty</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Department</label>
                    <select name="department_id" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="form-label">Assign Subjects (Hold Ctrl to select multiple)</label>
                    <select name="subject_ids[]" class="form-select" multiple size="5">
                        <?php foreach($subjects as $sub): ?>
                            <option value="<?php echo $sub['id']; ?>"><?php echo htmlspecialchars($sub['subject_name'] . ' (' . $sub['subject_code'] . ')'); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-muted">You can assign these later if needed.</small>
                </div>
                <button type="submit" name="add_teacher" class="btn btn-primary w-100">Add Faculty Member</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Existing Faculty Members</h5>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Department</th>
                            <th>Assigned Subjects</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($teachersQ as $teacher): 
                            // Fetch assigned subjects for this teacher
                            $stmt = $pdo->prepare("SELECT s.subject_code FROM subjects s JOIN teacher_subjects ts ON s.id = ts.subject_id WHERE ts.teacher_id = ?");
                            $stmt->execute([$teacher['id']]);
                            $assigned = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        ?>
                        <tr>
                            <td class="fw-bold"><?php echo htmlspecialchars($teacher['name']); ?></td>
                            <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                            <td><?php echo htmlspecialchars($teacher['dept_name']); ?></td>
                            <td>
                                <?php if(!empty($assigned)): ?>
                                    <span class="badge bg-primary"><?php echo implode('</span> <span class="badge bg-primary">', $assigned); ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">None</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this faculty member?');">
                                    <input type="hidden" name="id" value="<?php echo $teacher['id']; ?>">
                                    <button type="submit" name="delete_teacher" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($teachersQ)): ?>
                            <tr><td colspan="5" class="text-center text-muted">No faculty found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add_dept'])){
        $name = trim($_POST['name']);
        if(!empty($name)){
            try {
                $stmt = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
                $stmt->execute([$name]);
                $message = "<div class='alert alert-success'>Department added successfully.</div>";
            } catch(PDOException $e) {
                $message = "<div class='alert alert-danger'>Error: Could not add. It may already exist.</div>";
            }
        }
    } elseif(isset($_POST['delete_dept'])){
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM departments WHERE id = ?")->execute([$id]);
        $message = "<div class='alert alert-success'>Department deleted successfully.</div>";
    }
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Manage Departments</h2>
        <a href="dashboard.php" class="btn btn-secondary back-btn"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card p-4 mb-4">
            <h5 class="card-title fw-bold mb-3">Add Department</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Department Name</label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. BCA, BBA, BCom" required>
                </div>
                <button type="submit" name="add_dept" class="btn btn-primary w-100">Add Department</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card p-4">
            <h5 class="card-title fw-bold mb-3">Existing Departments</h5>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($departments as $dept): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($dept['id']); ?></td>
                            <td><?php echo htmlspecialchars($dept['name']); ?></td>
                            <td>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this department? This will cascade delete related data.');">
                                    <input type="hidden" name="id" value="<?php echo $dept['id']; ?>">
                                    <button type="submit" name="delete_dept" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($departments)): ?>
                            <tr><td colspan="3" class="text-center text-muted">No departments found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add_student'])){
        $enrollment_number = trim($_POST['enrollment_number']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $department_id = $_POST['department_id'];
        $semester = $_POST['semester'];
        $name = trim($_POST['name']);
        
        try {
            $stmt = $pdo->prepare("INSERT INTO students (enrollment_number, password, department_id, semester, name) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$enrollment_number, $password, $department_id, $semester, $name]);
            $message = "<div class='alert alert-success'>Student added successfully.</div>";
        } catch(PDOException $e) {
            $message = "<div class='alert alert-danger'>Error: Enrollment number may already exist.</div>";
        }
    } elseif(isset($_POST['delete_student'])){
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM students WHERE id = ?")->execute([$id]);
        $message = "<div class='alert alert-success'>Student deleted successfully.</div>";
    }
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
$students = $pdo->query("SELECT s.*, d.name as dept_name FROM students s LEFT JOIN departments d ON s.department_id = d.id ORDER BY s.semester, s.name")->fetchAll();

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Manage Students</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Add Student</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Enrollment Number</label>
                    <input type="text" name="enrollment_number" class="form-control" placeholder="e.g. EN1001" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Department</label>
                    <select name="department_id" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="form-label">Semester</label>
                    <select name="semester" class="form-select" required>
                        <option value="">-- Select Semester --</option>
                        <?php for($i=1; $i<=10; $i++): ?>
                            <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit" name="add_student" class="btn btn-primary w-100">Add Student</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card p-4">
            <h5 class="fw-bold mb-3">Existing Students</h5>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Enrollment No.</th>
                            <th>Name</th>
                            <th>Department & Sem</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($students as $student): ?>
                        <tr>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($student['enrollment_number']); ?></span></td>
                            <td class="fw-bold"><?php echo htmlspecialchars($student['name']); ?></td>
                            <td><?php echo htmlspecialchars($student['dept_name']); ?> - Sem <?php echo $student['semester']; ?></td>
                            <td>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this student?');">
                                    <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
                                    <button type="submit" name="delete_student" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($students)): ?>
                            <tr><td colspan="4" class="text-center text-muted">No students found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

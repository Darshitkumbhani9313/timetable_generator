<?php
require_once __DIR__ . '/config/db.php';

try {
    // 1. Alter table
    // Check if column exists first
    $check = $pdo->query("SHOW COLUMNS FROM time_slots LIKE 'is_break'");
    if($check->rowCount() == 0) {
        $pdo->exec("ALTER TABLE time_slots ADD COLUMN is_break TINYINT(1) DEFAULT 0");
        echo "Added is_break column.\n";
    }

    $pdo->beginTransaction();
    $pdo->exec("DELETE FROM time_slots");

    // 2. Define the new slots WITH breaks
    $slots = [
        ['07:30:00', '08:25:00', 0],
        ['08:25:00', '09:20:00', 0],
        ['09:20:00', '09:50:00', 1], // Break 1
        ['09:50:00', '10:45:00', 0],
        ['10:45:00', '11:40:00', 0],
        ['11:40:00', '11:50:00', 1], // Break 2
        ['11:50:00', '12:45:00', 0],
        ['12:45:00', '13:40:00', 0]
    ];
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    $insert = $pdo->prepare("INSERT INTO time_slots (day_of_week, start_time, end_time, is_break) VALUES (?, ?, ?, ?)");
    
    $count = 0;
    foreach ($days as $day) {
        foreach ($slots as $slot) {
            $insert->execute([$day, $slot[0], $slot[1], $slot[2]]);
            $count++;
        }
    }

    $pdo->commit();
    echo "Inserted slots with explicit breaks.\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

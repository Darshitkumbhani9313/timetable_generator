<?php
require_once __DIR__ . '/config/db.php';

try {
    // Check if the admins table exists first
    $stmt = $pdo->query("SHOW TABLES LIKE 'admins'");
    if ($stmt->rowCount() == 0) {
        echo "The 'admins' table does not exist. Did you run setup_db.php?\n";
        exit;
    }

    // Reset the admin password
    $username = 'admin';
    $password = 'admin123';
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) {
        $update = $pdo->prepare("UPDATE admins SET password = ? WHERE username = ?");
        $update->execute([$hash, $username]);
        echo "Admin password reset successfully for user: $username.\n";
    } else {
        $insert = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
        $insert->execute([$username, $hash]);
        echo "Admin user created successfully with username: $username.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

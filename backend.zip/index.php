<?php
session_start();
if(isset($_SESSION['admin_id'])) { header("Location: admin/dashboard.php"); exit; }
if(isset($_SESSION['teacher_id'])) { header("Location: teacher/teacher_dashboard.php"); exit; }
if(isset($_SESSION['student_id'])) { header("Location: student/student_dashboard.php"); exit; }
require_once 'includes/header.php';
?>
<div class="row align-items-center mb-5 mt-5">
    <div class="col-lg-6">
        <h1 class="display-4 fw-bold mb-4" style="color: var(--primary-color);">Automated Timetable Generator</h1>
        <p class="lead mb-4 text-muted">Streamline your scheduling process. Efficiently manage departments, subjects, faculty, and generate conflict-free timetables automatically.</p>
        <div class="d-grid gap-3 d-md-flex justify-content-md-start">
            <a href="admin/admin_login.php" class="btn btn-primary btn-lg px-4 me-md-2 shadow-sm"><i class="bi bi-shield-lock me-2"></i>Admin Portal</a>
            <a href="teacher/teacher_login.php" class="btn btn-outline-primary btn-lg px-4 bg-white shadow-sm"><i class="bi bi-person-workspace me-2"></i>Faculty Login</a>
            <a href="student/student_login.php" class="btn btn-outline-secondary btn-lg px-4 bg-white shadow-sm"><i class="bi bi-mortarboard me-2"></i>Student Login</a>
        </div>
    </div>
    <div class="col-lg-6 text-center mt-5 mt-lg-0">
        <div class="p-5 bg-white rounded-circle shadow d-inline-block" style="width: 350px; height: 350px; display: flex !important; align-items: center; justify-content: center; background: linear-gradient(135deg, rgba(79, 70, 229, 0.1), rgba(236, 72, 153, 0.1)); border: 10px solid white;">
            <i class="bi bi-calendar-check" style="font-size: 10rem; color: var(--primary-color); background: -webkit-linear-gradient(135deg, var(--primary-color), var(--secondary-color)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
        </div>
    </div>
</div>

<div class="row g-4 py-5 row-cols-1 row-cols-lg-3 mt-4 border-top">
      <div class="col d-flex align-items-start">
        <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3 rounded p-3 shadow-sm">
          <i class="bi bi-cpu text-primary fs-2"></i>
        </div>
        <div>
          <h3 class="fs-4 text-body-emphasis">Auto Generation</h3>
          <p class="text-muted">Generate Weekly timetables automatically with zero time conflicts and optimized classroom usage.</p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3 rounded p-3 shadow-sm">
          <i class="bi bi-layout-text-sidebar-reverse text-primary fs-2"></i>
        </div>
        <div>
          <h3 class="fs-4 text-body-emphasis">Faculty Dashboard</h3>
          <p class="text-muted">Teachers can easily view their specific schedules and manage their allocated subjects securely.</p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3 rounded p-3 shadow-sm">
          <i class="bi bi-journal-bookmark-fill text-primary fs-2"></i>
        </div>
        <div>
          <h3 class="fs-4 text-body-emphasis">Student Access</h3>
          <p class="text-muted">Students can login to instantly view and print their class timetable based on their semester.</p>
        </div>
      </div>
</div>
<?php require_once 'includes/footer.php'; ?>

</div> <!-- End container -->

<footer class="bg-dark text-white text-center py-4 mt-auto w-100 mt-5">
    <div class="container">
        <p class="mb-0">&copy; <?php echo date('Y'); ?> Automated Timetable Generator. All rights reserved.</p>
    </div>
</footer>

<!-- Bootstrap JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom Scripts if any -->
</body>
</html>

<?php
require_once __DIR__ . '/config/db.php';

try {
    $pdo->exec("ALTER TABLE classrooms MODIFY type ENUM('Classroom', 'Computer Lab') DEFAULT 'Classroom'");
    $pdo->exec("UPDATE classrooms SET type = 'Computer Lab' WHERE type = 'Lab'");
    echo "Database successfully altered!\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

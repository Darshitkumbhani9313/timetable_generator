<?php
session_start();
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
require_once '../config/db.php';

$deptCount = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$subjectCount = $pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
$teacherCount = $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$studentCount = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$roomCount = $pdo->query("SELECT COUNT(*) FROM classrooms")->fetchColumn();

require_once '../includes/header.php';
?>
<div class="row align-items-center mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-dark"><i class="bi bi-speedometer2 me-2 text-primary"></i>Admin Dashboard</h2>
        <p class="text-muted">Overview of timetable system resources and management tools.</p>
    </div>
    <div class="col-md-4 text-md-end">
        <a href="generate_timetable.php" class="btn btn-primary btn-lg shadow-sm"><i class="bi bi-magic me-2"></i>Generate Timetable</a>
    </div>
</div>

<div class="row g-4 mb-5">
    <div class="col-md-6 col-lg-3">
        <div class="card bg-primary text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #4f46e5, #3b82f6) !important;">
            <i class="bi bi-building fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo $deptCount; ?></h2>
            <p class="mb-0 text-white-50 form-label">Departments</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card bg-success text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #10b981, #34d399) !important;">
            <i class="bi bi-people fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo $teacherCount; ?></h2>
            <p class="mb-0 text-white-50 form-label">Faculty</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card bg-info text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #0ea5e9, #38bdf8) !important;">
            <i class="bi bi-book fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo $subjectCount; ?></h2>
            <p class="mb-0 text-white-50 form-label">Subjects</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card bg-warning text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #f59e0b, #fbbf24) !important;">
            <i class="bi bi-door-open fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo $roomCount; ?></h2>
            <p class="mb-0 text-white-50 form-label">Classrooms</p>
        </div>
    </div>
</div>

<h4 class="mb-4">Management Modules</h4>
<div class="row g-4">
    <div class="col-md-6 col-lg-4">
        <a href="manage_departments.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-primary border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-building fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">Manage Departments</h5>
                <p class="text-muted small mb-0">Add, edit, or remove departments/branches.</p>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="manage_subject.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-info border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-info bg-opacity-10 text-info rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-book fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">Manage Subjects</h5>
                <p class="text-muted small mb-0">Configure subjects, syllabus codes, and hours.</p>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="manage_teacher.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-success border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-person-video3 fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">Manage Faculty</h5>
                <p class="text-muted small mb-0">Add teachers and assign them subjects.</p>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="manage_classroom.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-warning border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-door-closed fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">Manage Classrooms</h5>
                <p class="text-muted small mb-0">Add rooms, labs, and specify their capacity.</p>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="manage_student.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-secondary border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-secondary bg-opacity-10 text-secondary rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-mortarboard fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">Manage Students</h5>
                <p class="text-muted small mb-0">Add or manage student enrollment records.</p>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="timetable_view.php" class="text-decoration-none">
            <div class="card text-center p-4 h-100 management-card border-top border-danger border-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-danger bg-opacity-10 text-danger rounded-circle mb-3 mx-auto" style="width: 60px; height: 60px;">
                    <i class="bi bi-calendar-grid-3x3 fs-3"></i>
                </div>
                <h5 class="text-dark fw-bold">View Timetables</h5>
                <p class="text-muted small mb-0">Browse generated timetables organically.</p>
            </div>
        </a>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

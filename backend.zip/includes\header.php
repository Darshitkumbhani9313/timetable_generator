<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automated Timetable Generator</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm custom-navbar">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/index.php"><i class="bi bi-calendar-event me-2"></i>TimetableGen</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <?php if(isset($_SESSION['admin_id'])): ?>
            <li class="nav-item"><a class="nav-link" href="/admin/dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php elseif(isset($_SESSION['teacher_id'])): ?>
            <li class="nav-item"><a class="nav-link" href="/teacher/teacher_dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php elseif(isset($_SESSION['student_id'])): ?>
            <li class="nav-item"><a class="nav-link" href="/student/student_dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="/admin/admin_login.php">Admin Login</a></li>
            <li class="nav-item"><a class="nav-link" href="/teacher/teacher_login.php">Teacher Login</a></li>
            <li class="nav-item"><a class="nav-link" href="/student/student_login.php">Student Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">

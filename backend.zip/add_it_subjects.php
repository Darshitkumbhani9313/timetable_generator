<?php
require_once __DIR__ . '/config/db.php';

try {
    // 1. Create or get IT Department
    $deptName = 'Information Technology';
    $stmt = $pdo->prepare("SELECT id FROM departments WHERE name = ?");
    $stmt->execute([$deptName]);
    $deptId = $stmt->fetchColumn();

    if (!$deptId) {
        $insertDept = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
        $insertDept->execute([$deptName]);
        $deptId = $pdo->lastInsertId();
        echo "Created IT Department with ID: $deptId\n";
    }

    // 2. Define 8 IT subjects
    $subjects = [
        ['semester' => 3, 'code' => 'IT301', 'name' => 'Data Structures and Algorithms', 'hours' => 4],
        ['semester' => 3, 'code' => 'IT302', 'name' => 'Object Oriented Programming', 'hours' => 3],
        ['semester' => 4, 'code' => 'IT401', 'name' => 'Database Management Systems', 'hours' => 4],
        ['semester' => 4, 'code' => 'IT402', 'name' => 'Operating Systems', 'hours' => 4],
        ['semester' => 5, 'code' => 'IT501', 'name' => 'Computer Networks', 'hours' => 3],
        ['semester' => 5, 'code' => 'IT502', 'name' => 'Web Technologies', 'hours' => 4],
        ['semester' => 6, 'code' => 'IT601', 'name' => 'Software Engineering', 'hours' => 3],
        ['semester' => 6, 'code' => 'IT602', 'name' => 'Information Security', 'hours' => 3]
    ];

    $insertSubject = $pdo->prepare("INSERT INTO subjects (department_id, semester, subject_code, subject_name, hours_per_week) VALUES (?, ?, ?, ?, ?)");
    
    $addedCount = 0;
    foreach ($subjects as $sub) {
        // Check if exists
        $check = $pdo->prepare("SELECT COUNT(*) FROM subjects WHERE subject_code = ?");
        $check->execute([$sub['code']]);
        if ($check->fetchColumn() == 0) {
            $insertSubject->execute([$deptId, $sub['semester'], $sub['code'], $sub['name'], $sub['hours']]);
            $addedCount++;
        }
    }
    
    echo "Added $addedCount IT subjects successfully!\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

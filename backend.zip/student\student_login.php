<?php
session_start();
require_once '../config/db.php';

if(isset($_SESSION['student_id'])) {
    header("Location: student_dashboard.php");
    exit;
}

$error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $enrollment_number = trim($_POST['enrollment_number']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password FROM students WHERE enrollment_number = ?");
    $stmt->execute([$enrollment_number]);
    $student = $stmt->fetch();

    if($student && password_verify($password, $student['password'])) {
        $_SESSION['student_id'] = $student['id'];
        header("Location: student_dashboard.php");
        exit;
    } else {
        $error = 'Invalid enrollment number or password';
    }
}
require_once '../includes/header.php';
?>
<div class="login-container">
    <div class="card p-4">
        <div class="text-center mb-4">
            <i class="bi bi-mortarboard-fill" style="font-size: 3rem; color: var(--primary-color);"></i>
            <h3 class="mt-2 fw-bold text-dark">Student Login</h3>
            <p class="text-muted">Login using your enrollment number.</p>
        </div>
        <?php if($error): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-bold">Enrollment Number</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-card-text"></i></span>
                    <input type="text" name="enrollment_number" class="form-control" placeholder="Enter enrollment number" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-bold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fs-5">Login</button>
        </form>
        <div class="mt-4 text-center">
            <a href="../index.php" class="text-decoration-none text-muted"><i class="bi bi-arrow-left me-1"></i> Back to Home</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

<?php
session_start();
if(!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
require_once '../config/db.php';

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['generate'])) {
    try {
        $pdo->beginTransaction();
        // 1. Clear existing timetable completely to avoid overlaps
        $pdo->exec("DELETE FROM timetable");

        // 2. Fetch required base data
        $time_slots = $pdo->query("SELECT * FROM time_slots ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time")->fetchAll(PDO::FETCH_ASSOC);
        $classrooms = $pdo->query("SELECT * FROM classrooms ORDER BY capacity DESC")->fetchAll(PDO::FETCH_ASSOC);
        $theory_rooms = array_filter($classrooms, fn($r) => $r['type'] !== 'Computer Lab');
        $lab_rooms = array_filter($classrooms, fn($r) => $r['type'] === 'Computer Lab');

        $subjects = $pdo->query("SELECT * FROM subjects")->fetchAll(PDO::FETCH_ASSOC);
        
        // Build a mapping of subject ID to assigned teacher IDs
        $teacher_subjects = $pdo->query("SELECT teacher_id, subject_id FROM teacher_subjects")->fetchAll(PDO::FETCH_ASSOC);
        $sub_teacher_map = [];
        foreach($teacher_subjects as $ts) {
            $sub_teacher_map[$ts['subject_id']][] = $ts['teacher_id'];
        }

        $success_count = 0;
        $fail_count = 0;

        // Greedy Heuristic Algorithm
        foreach($subjects as $sub) {
            $dept_id = $sub['department_id'];
            $sem = $sub['semester'];
            $sub_id = $sub['id'];
            
            $teachers_for_sub = $sub_teacher_map[$sub_id] ?? [];
            if(empty($teachers_for_sub)) {
                $fail_count++;
                continue; // No teacher is assigned to this subject, cannot schedule
            }
            $t_id = $teachers_for_sub[0]; // For simplicity, pick the first assigned teacher
            
            $hours_needed = (int)$sub['hours_per_week'];
            if ($hours_needed <= 0) $hours_needed = 4; // Backup default
            $scheduled = 0;
            $day_counts = []; // Track subject slots per day
            $is_lab = (stripos($sub['subject_name'], 'lab') !== false || stripos($sub['subject_name'], 'practical') !== false);
            
            // Allow up to 2 slots per day if hours > 4 or if it's a lab. Otherwise try to spread to 1 per day.
            $max_per_day = ($hours_needed >= 5 || $is_lab) ? 2 : 1;
            
            // 110-MINUTE CONTIGUOUS LAB RULE
            // If hours >= 5, try to schedule exactly 1 contiguous block of 2 slots in a Computer Lab
            if ($hours_needed >= 5 && !empty($lab_rooms)) {
                for($i = 0; $i < count($time_slots) - 1; $i++) {
                    $slot1 = $time_slots[$i];
                    $slot2 = $time_slots[$i+1];
                    
                    $day = $slot1['day_of_week'];
                    if($day != $slot2['day_of_week']) continue;
                    if($slot1['is_break'] == 1 || $slot2['is_break'] == 1) continue;
                    if(($day_counts[$day] ?? 0) > 0) continue; // Must have empty day for this
                    
                    $s1_id = $slot1['id'];
                    $s2_id = $slot2['id'];
                    
                    // Teachers & Cohort
                    $t_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ? AND time_slot_id IN (?, ?)");
                    $t_busy->execute([$t_id, $s1_id, $s2_id]);
                    if($t_busy->fetchColumn() > 0) continue; 
                    
                    $c_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE department_id = ? AND semester = ? AND time_slot_id IN (?, ?)");
                    $c_busy->execute([$dept_id, $sem, $s1_id, $s2_id]);
                    if($c_busy->fetchColumn() > 0) continue; 
                    
                    // Lab Room
                    $assigned_lab = null;
                    foreach($lab_rooms as $room) {
                        $r_id = $room['id'];
                        $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id IN (?, ?)");
                        $r_busy->execute([$r_id, $s1_id, $s2_id]);
                        if($r_busy->fetchColumn() == 0) {
                            $assigned_lab = $r_id;
                            break;
                        }
                    }
                    
                    if($assigned_lab) {
                        $stmt = $pdo->prepare("INSERT INTO timetable (department_id, semester, subject_id, teacher_id, classroom_id, time_slot_id) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_lab, $s1_id]);
                        $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_lab, $s2_id]);
                        $scheduled += 2;
                        $day_counts[$day] = ($day_counts[$day] ?? 0) + 2;
                        break; // Lab successfully scheduled (1 block of 110 minutes)
                    }
                }
            }
            
            foreach($time_slots as $slot) {
                if($scheduled >= $hours_needed) break; 
                if($slot['is_break'] == 1) continue;
                
                $day = $slot['day_of_week'];
                if(($day_counts[$day] ?? 0) >= $max_per_day) continue;
                
                $slot_id = $slot['id'];
                
                // Rule 1: Is Cohort busy?
                $c_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE department_id = ? AND semester = ? AND time_slot_id = ?");
                $c_busy->execute([$dept_id, $sem, $slot_id]);
                if($c_busy->fetchColumn() > 0) continue; 
                
                // Rule 2: Is Teacher busy?
                $t_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ? AND time_slot_id = ?");
                $t_busy->execute([$t_id, $slot_id]);
                if($t_busy->fetchColumn() > 0) continue; 
                
                // Rule 3: Find a free Classroom
                $assigned_room = null;
                // If lab subject, try lab rooms first. Else try theory rooms first.
                $preferred_rooms = $is_lab && !empty($lab_rooms) ? $lab_rooms : (empty($theory_rooms) ? $classrooms : $theory_rooms);
                $fallback_rooms = $is_lab ? $theory_rooms : $lab_rooms;
                
                // Search preferred
                foreach($preferred_rooms as $room) {
                    $r_id = $room['id'];
                    $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id = ?");
                    $r_busy->execute([$r_id, $slot_id]);
                    if($r_busy->fetchColumn() == 0) {
                        $assigned_room = $r_id;
                        break;
                    }
                }
                
                // Search fallback if preferred not found
                if (!$assigned_room) {
                    foreach($fallback_rooms as $room) {
                        $r_id = $room['id'];
                        $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id = ?");
                        $r_busy->execute([$r_id, $slot_id]);
                        if($r_busy->fetchColumn() == 0) {
                            $assigned_room = $r_id;
                            break;
                        }
                    }
                }
                
                if($assigned_room) {
                    $stmt = $pdo->prepare("INSERT INTO timetable (department_id, semester, subject_id, teacher_id, classroom_id, time_slot_id) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_room, $slot_id]);
                    $scheduled++;
                    $day_counts[$day] = ($day_counts[$day] ?? 0) + 1;
                }
            }
            
            // If strictly 1 per day failed, try a second pass allowing 2 per day (if we initially restricted to 1)
            if($scheduled < $hours_needed && $max_per_day == 1) {
                foreach($time_slots as $slot) {
                    if($scheduled >= $hours_needed) break; 
                    if($slot['is_break'] == 1) continue;
                    
                    $day = $slot['day_of_week'];
                    if(($day_counts[$day] ?? 0) >= 2) continue; // Allow up to 2 now
                    
                    $slot_id = $slot['id'];
                    
                    $c_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE department_id = ? AND semester = ? AND time_slot_id = ?");
                    $c_busy->execute([$dept_id, $sem, $slot_id]);
                    if($c_busy->fetchColumn() > 0) continue; 
                    
                    $t_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ? AND time_slot_id = ?");
                    $t_busy->execute([$t_id, $slot_id]);
                    if($t_busy->fetchColumn() > 0) continue; 
                    
                    $assigned_room = null;
                    foreach($classrooms as $room) {
                        $r_id = $room['id'];
                        $r_busy = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE classroom_id = ? AND time_slot_id = ?");
                        $r_busy->execute([$r_id, $slot_id]);
                        if($r_busy->fetchColumn() == 0) {
                            $assigned_room = $r_id;
                            break;
                        }
                    }
                    
                    if($assigned_room) {
                        $stmt = $pdo->prepare("INSERT INTO timetable (department_id, semester, subject_id, teacher_id, classroom_id, time_slot_id) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$dept_id, $sem, $sub_id, $t_id, $assigned_room, $slot_id]);
                        $scheduled++;
                        $day_counts[$day] = ($day_counts[$day] ?? 0) + 1;
                    }
                }
            }
            
            if($scheduled == $hours_needed) {
                $success_count++;
            } else {
                if ($scheduled > 0) $success_count++; // Trigger partial success flag warning
                $fail_count++; // Didn't find enough slots
            }
        }
        
        $pdo->commit();
        if($fail_count == 0 && $success_count > 0){
            $message = "<div class='alert alert-success'><i class='bi bi-check-circle-fill me-2'></i>Timetable generated successfully! Fully scheduled $success_count subjects.</div>";
        } else if($success_count > 0) {
            $message = "<div class='alert alert-warning'><i class='bi bi-exclamation-triangle-fill me-2'></i>Generated with warnings. Scheduled $success_count subjects, but $fail_count subjects could not be fully mapped due to lack of resources (teachers, rooms, or slots).</div>";
        } else {
            $message = "<div class='alert alert-danger'><i class='bi bi-x-circle-fill me-2'></i>Failed to schedule any subjects. Please ensure subjects, teachers, and rooms are properly added and linked.</div>";
        }
    } catch(Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

$last_count = $pdo->query("SELECT COUNT(*) FROM timetable")->fetchColumn();

require_once '../includes/header.php';
?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2>Generate Timetable</h2>
        <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Back to Dashboard</a>
    </div>
</div>

<?php echo $message; ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card p-5 text-center shadow-sm border-0">
            <div class="mb-4">
                <i class="bi bi-cpu" style="font-size: 5rem; color: var(--primary-color);"></i>
            </div>
            <h3 class="fw-bold mb-3">Algorithm Generator</h3>
            <p class="text-muted mb-4">Click the button below to auto-generate the timetable for all departments and semesters. 
            <br><strong>Warning:</strong> This will overwrite the currently existing timetable.</p>
            
            <form method="POST" onsubmit="return confirm('Are you sure? This will delete the current timetable and generate a new one.');">
                <button type="submit" name="generate" class="btn btn-primary btn-lg px-5 py-3 rounded-pill fw-bold shadow">
                    <i class="bi bi-magic me-2"></i> Run Generation Algorithm
                </button>
            </form>
            
            <hr class="my-5">
            
            <h4>Current Timetable Status</h4>
            <?php if($last_count > 0): ?>
                <p class="text-success fw-bold"><i class="bi bi-check-circle me-1"></i> System currently holds <?php echo $last_count; ?> scheduled active slots.</p>
                <a href="timetable_view.php" class="btn btn-outline-primary"><i class="bi bi-calendar-grid-3x3 me-2"></i>View Current Timetables</a>
            <?php else: ?>
                <p class="text-danger fw-bold"><i class="bi bi-x-circle me-1"></i> No timetable data found in the database. Please generate one.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

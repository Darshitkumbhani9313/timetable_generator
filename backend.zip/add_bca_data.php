<?php
require_once __DIR__ . '/config/db.php';

try {
    $pdo->beginTransaction();

    // 1. Department
    $deptName = 'BCA';
    $stmt = $pdo->prepare("SELECT id FROM departments WHERE name = ?");
    $stmt->execute([$deptName]);
    $deptId = $stmt->fetchColumn();
    if (!$deptId) {
        $insertDept = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
        $insertDept->execute([$deptName]);
        $deptId = $pdo->lastInsertId();
    }

    // 2. Subjects (5 hours_per_week: 3 theory + 2 lab slots)
    $subjectNames = ['c', 'c++', 'java', 'maths', 'php', 'ds', 'htm', 'fsed'];
    $subjectIds = [];
    $insertSubject = $pdo->prepare("INSERT INTO subjects (department_id, semester, subject_code, subject_name, hours_per_week) VALUES (?, ?, ?, ?, ?)");
    foreach ($subjectNames as $i => $subName) {
        $code = 'BCA' . (101 + $i);
        $check = $pdo->prepare("SELECT id FROM subjects WHERE subject_code = ?");
        $check->execute([$code]);
        $subId = $check->fetchColumn();
        if (!$subId) {
            $insertSubject->execute([$deptId, $i + 1, $code, strtoupper($subName), 5]); // Semester 1 to 8, 5 hrs/wk
            $subId = $pdo->lastInsertId();
        }
        $subjectIds[] = $subId;
    }

    // 3. Teachers
    $teacherNames = ['jay', 'ram', 'rames', 'piyush', 'jank', 'hardik', 'dharmes', 'mayus'];
    $insertTeacher = $pdo->prepare("INSERT INTO teachers (name, email, password, department_id) VALUES (?, ?, ?, ?)");
    $insertTS = $pdo->prepare("INSERT IGNORE INTO teacher_subjects (teacher_id, subject_id) VALUES (?, ?)");
    foreach ($teacherNames as $i => $name) {
        $email = strtolower($name) . '@example.com';
        $check = $pdo->prepare("SELECT id FROM teachers WHERE email = ?");
        $check->execute([$email]);
        $teacherId = $check->fetchColumn();
        if (!$teacherId) {
            $insertTeacher->execute([ucfirst($name), $email, password_hash('password123', PASSWORD_DEFAULT), $deptId]);
            $teacherId = $pdo->lastInsertId();
        }
        if (isset($subjectIds[$i])) {
            $insertTS->execute([$teacherId, $subjectIds[$i]]);
        }
    }

    // 4. Classrooms (Theory)
    $classrooms = ['301', '302', '303', '304', '305', '306'];
    $insertRoom = $pdo->prepare("INSERT IGNORE INTO classrooms (room_number, capacity, type) VALUES (?, ?, ?)");
    foreach ($classrooms as $room) {
        $insertRoom->execute([$room, 60, 'Classroom']);
    }

    // 5. Labs
    $labs = ['a1', 'a2', 'a3', 'a4', 'a5'];
    foreach ($labs as $lab) {
        $insertRoom->execute([strtoupper($lab), 40, 'Computer Lab']);
    }

    $pdo->commit();
    echo "BCA Data specifically re-seeded with exactly 5 hours per week per subject.\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "Error: " . $e->getMessage() . "\n";
}
?>

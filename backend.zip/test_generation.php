<?php
// Mock session to bypass login check in generate_timetable.php
session_start();
$_SESSION['admin_id'] = 1;

$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST['generate'] = '1';

// We change dir so requires in generate_timetable.php work properly
chdir(__DIR__ . '/admin');

ob_start();
require_once 'generate_timetable.php';
$output = ob_get_clean();

// Check if message generated successfully
if(strpos($output, 'Timetable generated successfully') !== false) {
    echo "SUCCESS: Timetable generated.\n";
} else if(strpos($output, 'Generated with warnings') !== false) {
    echo "WARNING: Timetable generated with warnings.\n";
} else {
    echo "FAILED: Timetable failed to generate.\n";
}

require_once '../config/db.php';
$count = $pdo->query("SELECT COUNT(*) FROM timetable")->fetchColumn();
echo "Total scheduled classes: " . $count . "\n\n";

$verify = $pdo->query("
    SELECT t.semester, s.subject_name, count(*) as slot_count 
    FROM timetable t 
    JOIN subjects s ON t.subject_id = s.id 
    GROUP BY t.department_id, t.semester, t.subject_id
    ORDER BY t.semester ASC
")->fetchAll(PDO::FETCH_ASSOC);

foreach($verify as $v) {
    echo "Semester {$v['semester']} - {$v['subject_name']}: {$v['slot_count']} slots\n";
}
?>

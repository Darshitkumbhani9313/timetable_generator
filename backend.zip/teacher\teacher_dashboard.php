<?php
session_start();
if(!isset($_SESSION['teacher_id'])) { header("Location: teacher_login.php"); exit; }
require_once '../config/db.php';

$t_id = $_SESSION['teacher_id'];

// Get teacher info
$stmt = $pdo->prepare("SELECT t.*, d.name as dept_name FROM teachers t LEFT JOIN departments d ON t.department_id = d.id WHERE t.id = ?");
$stmt->execute([$t_id]);
$teacher = $stmt->fetch();

// Get assigned subjects
$stmt = $pdo->prepare("SELECT s.subject_code, s.subject_name, s.semester FROM teacher_subjects ts JOIN subjects s ON ts.subject_id = s.id WHERE ts.teacher_id = ?");
$stmt->execute([$t_id]);
$subjects = $stmt->fetchAll();

// Get total classes this week
$stmt = $pdo->prepare("SELECT COUNT(*) FROM timetable WHERE teacher_id = ?");
$stmt->execute([$t_id]);
$class_count = $stmt->fetchColumn();

// Get today's classes
$today = date('l'); // 'Monday'
$stmt = $pdo->prepare("SELECT t.*, s.subject_name, c.room_number, ts.start_time, ts.end_time, d.name as dept_name
                       FROM timetable t
                       JOIN subjects s ON t.subject_id = s.id
                       JOIN classrooms c ON t.classroom_id = c.id
                       JOIN time_slots ts ON t.time_slot_id = ts.id
                       JOIN departments d ON t.department_id = d.id
                       WHERE t.teacher_id = ? AND ts.day_of_week = ?
                       ORDER BY ts.start_time");
$stmt->execute([$t_id, $today]);
$todays_classes = $stmt->fetchAll();

require_once '../includes/header.php';
?>
<div class="row align-items-center mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-dark">Welcome, <?php echo htmlspecialchars($teacher['name']); ?></h2>
        <p class="text-muted"><i class="bi bi-building me-1"></i> Department of <?php echo htmlspecialchars($teacher['dept_name']); ?></p>
    </div>
    <div class="col-md-4 text-md-end">
        <a href="view_schedule.php" class="btn btn-primary btn-lg shadow-sm"><i class="bi bi-calendar-event me-2"></i>My Full Schedule</a>
    </div>
</div>

<div class="row g-4 mb-5">
    <div class="col-md-6 col-lg-4">
        <div class="card bg-info text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #0ea5e9, #38bdf8) !important;">
            <i class="bi bi-book fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo count($subjects); ?></h2>
            <p class="mb-0 text-white-50">Assigned Subjects</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card bg-success text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #10b981, #34d399) !important;">
            <i class="bi bi-calendar-check fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo $class_count; ?></h2>
            <p class="mb-0 text-white-50">Total Classes / Week</p>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card bg-warning text-white text-center p-4 border-0" style="background: linear-gradient(135deg, #f59e0b, #fbbf24) !important;">
            <i class="bi bi-clock-history fs-1 mb-2"></i>
            <h2 class="fw-bold mb-0"><?php echo count($todays_classes); ?></h2>
            <p class="mb-0 text-white-50">Classes Today (<?php echo $today; ?>)</p>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card p-4 shadow-sm border-0 h-100">
            <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="bi bi-list-check me-2 text-primary"></i>Your Subjects</h5>
            <?php if(!empty($subjects)): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach($subjects as $sub): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <div>
                                <span class="fw-bold"><?php echo htmlspecialchars($sub['subject_name']); ?></span>
                                <br><small class="text-muted">Semester <?php echo $sub['semester']; ?></small>
                            </div>
                            <span class="badge bg-secondary rounded-pill"><?php echo htmlspecialchars($sub['subject_code']); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="text-center py-4">
                    <p class="text-muted">No subjects assigned yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card p-4 shadow-sm border-0 h-100">
            <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="bi bi-calendar-day me-2 text-success"></i>Today's Classes</h5>
            <?php if(!empty($todays_classes)): ?>
                <div class="timeline">
                    <?php foreach($todays_classes as $class): ?>
                        <div class="d-flex mb-3 align-items-start position-relative">
                            <div class="text-end me-3" style="min-width: 90px;">
                                <small class="text-muted fw-bold d-block"><?php echo date("g:i A", strtotime($class['start_time'])); ?></small>
                                <small class="text-muted"><?php echo date("g:i A", strtotime($class['end_time'])); ?></small>
                            </div>
                            <div class="bg-light p-3 rounded-3 flex-grow-1 border-start border-primary border-4">
                                <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($class['subject_name']); ?></h6>
                                <p class="mb-0 small text-muted">
                                    <i class="bi bi-door-open me-1"></i> Room <?php echo htmlspecialchars($class['room_number']); ?> &nbsp;|&nbsp;
                                    <i class="bi bi-person-badge me-1"></i> <?php echo htmlspecialchars($class['dept_name']); ?> Sem <?php echo $class['semester']; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="bi bi-cup-hot text-muted fs-1 mb-3 d-block"></i>
                    <p class="text-muted fw-bold">No classes for today! Enjoy your break.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

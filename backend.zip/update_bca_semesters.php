<?php
require_once __DIR__ . '/config/db.php';

try {
    $subjectNames = ['c', 'c++', 'java', 'maths', 'php', 'ds', 'htm', 'fsed'];
    $stmt = $pdo->prepare("UPDATE subjects SET semester = ? WHERE subject_code = ? AND department_id = (SELECT id FROM departments WHERE name='BCA')");
    
    foreach ($subjectNames as $index => $subName) {
        $semester = $index + 1; // 1 to 8
        $code = 'BCA' . (101 + $index);
        $stmt->execute([$semester, $code]);
        echo "Updated subject $code ($subName) to Semester $semester\n";
    }

    echo "Successfully assigned semesters 1 to 8 to the BCA subjects.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
